# iCYPRESSS


To Install
pip install torch_geometric
conda install pytorch-scatter -c pyg
pip install iCypres