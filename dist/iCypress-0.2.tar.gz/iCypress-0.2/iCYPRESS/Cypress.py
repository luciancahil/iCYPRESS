
class Cypress:
    def __init__(self):
        print("hi")
    
    def stuff(self):
        print("why?")